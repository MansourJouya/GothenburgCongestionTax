﻿using System;
using Xunit;
using congestion.calculator.Models;


namespace CongestionTaxCalculator.Tests.MotorbikeTests
{
    // Note for Development Team:
    // This class contains unit tests for the Motorbike class, verifying its functionality.

    // Purpose:
    // The tests in this class ensure that the Motorbike class correctly identifies its vehicle type
    // and that the GetTax method applies the correct rules for tax calculation.

    public class MotorbikeTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Motorbike _vehicle;

        public MotorbikeTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Motorbike(); // Test with a motorbike
        }
 



        // Test to ensure that no tax is applied for a motorbike on a public holiday.
        [Fact]
        public void GetTax_Motorbike_NoTaxOnPublicHoliday()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 05, 01, 10, 00, 00) }; // Public holiday (Labor Day)
            int expectedTax = 0; // Expected tax is zero for motorbikes

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify that the result matches the expected tax
        }
    }
}
