﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.EmergencyVehicleTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator specifically focusing on vehicles that are exempt from congestion tax.
    // 
    // Purpose:
    // These tests verify that the calculator correctly identifies exempt vehicles (like Emergency Vehicles)
    // and consistently returns a tax amount of zero under various conditions: 
    // 1. During regular weekday hours.
    // 2. On public holidays.
    // 
    // Importance:
    // Maintaining accurate tax calculations for exempt vehicles is crucial for the integrity of the application.
    // If any changes are made to the calculator's logic regarding exemptions in the future,
    // ensure these tests are reviewed and updated as necessary to reflect those changes.

    public class ExemptVehicleTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly EmergencyVehicle _vehicle;

        public ExemptVehicleTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new EmergencyVehicle(); // Exempt vehicle type
        }

        // This test checks that the tax for an exempt vehicle (e.g., an EmergencyVehicle) is correctly returned as zero during a specified date and time.
        [Fact]
        public void GetTax_ExemptVehicle_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 14, 07, 00, 00) }; // Test date within taxable hours
            int expectedTax = 0; // Expected tax is zero

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify that the result matches the expected tax
        }

        // This test verifies that the tax for an exempt vehicle on a regular weekday is correctly returned as zero.
        [Fact]
        public void GetTax_ExemptVehicleOnWeekday_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 14, 09, 00, 00) }; // Weekday during taxable hours
            int expectedTax = 0; // Expected tax is zero

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify that the result matches the expected tax
        }

        // This test checks that the tax for an exempt vehicle on a public holiday is correctly returned as zero.
        [Fact]
        public void GetTax_VehicleExemptOnPublicHoliday_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 05, 01, 10, 00, 00) }; // Public holiday (Labor Day)
            int expectedTax = 0; // Expected tax is zero

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify that the result matches the expected tax
        }

        // This test ensures that for exempt vehicles, no tax is applied at any time, including during taxable hours.
        [Fact]
        public void GetTax_TaxExemptVehicle_ReturnsZeroTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 14, 08, 00, 00) }; // Test time during taxable hours
            int expectedTax = 0; // Expected tax is zero

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify that the result matches the expected tax
        }
    }
}
