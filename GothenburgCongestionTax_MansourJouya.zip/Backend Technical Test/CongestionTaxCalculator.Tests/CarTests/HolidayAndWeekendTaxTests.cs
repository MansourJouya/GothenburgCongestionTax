﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, focusing on the tax rules 
    // related to holidays and weekends.
    // 
    // Purpose:
    // Verify that the calculator correctly applies the rules for exempting vehicles from congestion tax
    // on weekends and public holidays. 
    // 
    // Scenarios covered:
    // 1. No tax is applied on weekends.
    // 2. No tax is applied on public holidays.
    // 3. No tax is applied on multiple dates that are either holidays or weekends.
    // 
    // Importance:
    // Ensuring accurate tax calculations for holidays and weekends is crucial for compliance
    // with local regulations and maintaining user trust in the application.

    public class HolidayAndWeekendTaxTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public HolidayAndWeekendTaxTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car(); // Test with a standard car
        }

        [Fact]
        public void GetTax_NoTaxOnWeekend_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 12, 10, 00, 00) }; // Saturday
            int expectedTax = 0; // No tax on weekends

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_NoTaxOnPublicHoliday_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 12, 25, 10, 00, 00) }; // Christmas Day
            int expectedTax = 0; // No tax on holidays

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_NoTaxOnMultipleHolidaysAndWeekends_ReturnsZero()
        {
            // Arrange
            DateTime[] dates =
            {
                new DateTime(2013, 01, 01, 10, 00, 00), // New Year's Day
                new DateTime(2013, 01, 12, 10, 00, 00)  // Saturday
            };
            int expectedTax = 0; // No tax on specified dates

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_NoTaxOnHolidayDate_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 01, 10, 00, 00) }; // New Year's Day
            int expectedTax = 0; // No tax should be applied

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_NoTaxOnDayBeforePublicHoliday_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 03, 27, 14, 00, 00) }; // Day before a public holiday
            int expectedTax = 0; // No tax should be applied

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        // Tests for additional holiday and weekend scenarios
        [Fact]
        public void GetTax_TaxApplicableDuringPublicHoliday_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 01, 10, 00, 00) }; // New Year's Day
            int expectedTax = 0; // No tax should be applied

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TaxApplicableDuringWeekend_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 12, 10, 00, 00) }; // Saturday
            int expectedTax = 0; // No tax should be applied

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }
    }
}
