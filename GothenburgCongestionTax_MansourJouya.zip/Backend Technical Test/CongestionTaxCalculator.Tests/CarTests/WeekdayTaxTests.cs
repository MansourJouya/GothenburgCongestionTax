﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, focusing on tax calculations 
    // applicable during weekdays.

    // Purpose:
    // The tests in this class verify that the calculator correctly applies the tax rules for 
    // various times during weekdays. The following scenarios are covered:
    // 1. Tax applicable during weekday morning.
    // 2. Tax applicable during weekday evening.
    // 3. Tax applicable during weekday midday.
    // 4. Tax applicable during late evening (after tax hours).

    // Importance:
    // Accurate tax calculations during weekdays are essential for compliance with regulations 
    // and for providing users with correct billing information. 
    // Any changes to the tax calculation logic should be reflected in these tests.


    public class WeekdayTaxTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public WeekdayTaxTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car();  
        }

        // Test to ensure the correct tax is applied during weekday morning.
        [Fact]
        public void GetTax_TaxApplicableDuringWeekdayMorning_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates =
            {
                new DateTime(2013, 01, 14, 07, 00, 00), // Expected tax: 18 kr
            };
            int expectedTax = 18; // Expected value

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to ensure the correct tax is applied during weekday evening.
        [Fact]
        public void GetTax_TaxApplicableDuringWeekdayEvening_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates =
            {
                new DateTime(2013, 01, 14, 17, 30, 00), // Expected tax: 13 kr
            };
            int expectedTax = 13;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to ensure the correct tax is applied during weekday midday.
        [Fact]
        public void GetTax_TaxApplicableDuringWeekdayMidday_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates =
            {
                new DateTime(2013, 01, 14, 12, 00, 00), // Expected tax: 8 kr
            };
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to ensure that no tax is applied during late evening hours.
        [Fact]
        public void GetTax_TaxApplicableDuringWeekdayLateEvening_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates =
            {
                new DateTime(2013, 01, 14, 20, 00, 00), // Expected tax: 0 kr (no tax after 18:00)
            };
            int expectedTax = 0; // No tax after 18:00

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }
    }
}
