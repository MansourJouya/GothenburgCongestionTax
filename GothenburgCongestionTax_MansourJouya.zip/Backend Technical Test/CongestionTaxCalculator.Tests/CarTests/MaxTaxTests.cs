﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, specifically focusing on 
    // the maximum tax calculations.
    // 
    // Purpose:
    // These tests verify that the calculator correctly applies the rules for 
    // maximum congestion tax, ensuring that the total tax charged does not exceed the specified limits.
    // 
    // Scenarios covered:
    // 1. Maximum tax is charged for a single day.
    // 2. Tax is correctly capped over multiple entries in one day.
    // 3. Ensuring that a single vehicle is not charged more than the maximum tax limit across multiple entries.
    // 
    // Importance:
    // Accurate calculations of maximum tax limits are critical to ensure compliance with local regulations 
    // and maintain trust in the application's accuracy.

    public class MaxTaxTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public MaxTaxTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car(); // Test with a standard car
        }

        [Fact]
        public void GetTax_SingleDayMaxTax_ReturnsMaxTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 02, 08, 06, 20, 27), // Entry in the morning
                new DateTime(2013, 02, 08, 14, 35, 00), // Entry in the afternoon
                new DateTime(2013, 02, 08, 15, 47, 00)  // Another entry in the afternoon
            };
            int expectedTax = 34; // Maximum tax for the day

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected maximum tax amount
        }

        [Fact]
        public void GetTax_TaxApplicableMultipleDays_ReturnsCappedTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kronor
                new DateTime(2013, 01, 14, 08, 00, 00), // 13 kronor
                new DateTime(2013, 01, 14, 09, 00, 00), // 8 kronor
                new DateTime(2013, 01, 14, 10, 00, 00), // 8 kronor
                new DateTime(2013, 01, 14, 11, 00, 00), // 8 kronor
                new DateTime(2013, 01, 14, 12, 00, 00)  // 8 kronor
            };
            int expectedTax = 60; // Maximum tax capped at 60 kronor

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected capped tax amount
        }

        [Fact]
        public void GetTax_SingleChargeRule_TaxDoesNotExceedMax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 06, 30, 00), // 13 kronor
                new DateTime(2013, 01, 14, 07, 30, 00), // 18 kronor
                new DateTime(2013, 01, 14, 08, 30, 00), // 8 kronor
                new DateTime(2013, 01, 14, 09, 30, 00), // 8 kronor
                new DateTime(2013, 01, 14, 10, 30, 00)  // 8 kronor
            };
            int expectedTax = 55; // Total should not exceed maximum tax of 60 kronor

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }
    }
}
