﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, specifically focusing on scenarios
    // involving multiple entries for a vehicle on different dates and their associated tax calculations.
    // 
    // Purpose:
    // These tests verify that the calculator handles multiple entries correctly,
    // ensuring that the expected tax amounts are returned or that no tax is applied under certain conditions.
    // 
    // Scenarios covered:
    // 1. No tax should be applied on weekends for multiple entries.
    // 2. The tax is calculated correctly for specific dates with multiple entries.
    // 3. No tax should be applied during evening hours on holidays.
    // 4. No tax should be applied after tax hours on regular days.
    // 
    // Importance:
    // Ensuring accurate tax calculations for multiple entries is crucial for user trust and regulatory compliance.
    // Any changes to the tax calculation logic should prompt a review and potential update of these tests.

    public class MultipleEntriesTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public MultipleEntriesTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car(); // Test with a standard car
        }

        // Test to ensure no tax is applied for multiple entries on a weekend.
        [Fact]
        public void GetTax_WeekendWithMultipleEntries_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 12, 08, 00, 00), // Saturday
                new DateTime(2013, 01, 12, 10, 00, 00), // Saturday
            };
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to verify the expected tax for multiple entries across specific dates.
        [Fact]
        public void GetTax_PostItNoteDates_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 21, 00, 00),
                new DateTime(2013, 01, 15, 21, 00, 00),
                new DateTime(2013, 02, 07, 06, 23, 27),
                new DateTime(2013, 02, 07, 15, 27, 00),
                new DateTime(2013, 02, 08, 06, 27, 00),
                new DateTime(2013, 02, 08, 06, 20, 27),
                new DateTime(2013, 02, 08, 14, 35, 00),
                new DateTime(2013, 02, 08, 15, 29, 00),
                new DateTime(2013, 02, 08, 15, 47, 00),
                new DateTime(2013, 02, 08, 16, 01, 00),
                new DateTime(2013, 02, 08, 16, 48, 00),
                new DateTime(2013, 02, 08, 17, 49, 00),
                new DateTime(2013, 02, 08, 18, 29, 00),
                new DateTime(2013, 02, 08, 18, 35, 00),
                new DateTime(2013, 03, 26, 14, 25, 00),
                new DateTime(2013, 03, 28, 14, 07, 27),
            };
            int expectedTax = 60;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to ensure no tax is applied during evening hours on holidays.
        [Fact]
        public void GetTax_TaxApplicableDuringEveningOnHolidays_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 12, 24, 18, 00, 00), // Christmas Eve
            };
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to verify no tax is applied after tax hours.
        [Fact]
        public void GetTax_LateEvening_ReturnsZero()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 20, 00, 00), // After tax hours
            };
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        // Test to ensure only the highest tax is applied for multiple entries within the same hour.
        [Fact]
        public void GetTax_MultipleEntriesWithinAnHour_ReturnsHighestTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 14, 07, 15, 00), // 18 kr
                new DateTime(2013, 01, 14, 07, 30, 00)  // 13 kr
            };
            int expectedTax = 18; // Tax should be the highest value

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }
    }
}
