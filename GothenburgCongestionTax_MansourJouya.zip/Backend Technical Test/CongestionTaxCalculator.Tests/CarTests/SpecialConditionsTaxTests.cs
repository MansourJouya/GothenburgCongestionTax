﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, specifically focusing on special
    // conditions that affect tax calculations for vehicles.
    // 
    // Purpose:
    // These tests verify that the calculator correctly applies the tax rules under special conditions,
    // ensuring that the highest applicable tax is calculated correctly, caps are applied where necessary,
    // and that the tax for non-exempt vehicles is computed accurately.
    // 
    // Scenarios covered:
    // 1. Application of the single charge rule.
    // 2. Calculation of tax for multiple entries in the same minute.
    // 3. Capped tax for multiple charges with gaps in time.
    // 4. Determination of the highest tax for multiple charges within a 60-minute period.
    // 5. Total tax calculation for multiple days of charges.
    // 6. Correct tax application for non-exempt vehicles.
    // 
    // Importance:
    // Ensuring accurate tax calculations under special conditions is crucial for user trust and regulatory compliance.
    // Any changes to the tax calculation logic should prompt a review and potential update of these tests.

    public class SpecialConditionsTaxTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public SpecialConditionsTaxTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car(); // Test with a standard car
        }

        [Fact]
        public void GetTax_SingleChargeRule_AppliesCorrectly()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 14, 07, 30, 00), // 13 kr
                new DateTime(2013, 01, 14, 08, 00, 00)  // 13 kr
            };
            int expectedTax = 18; // Highest tax should be returned

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        [Fact]
        public void GetTax_MultipleTaxApplicableInSameMinute_ReturnsHighestTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 14, 07, 00, 01), // 18 kr
            };
            int expectedTax = 18; // Highest tax should be calculated

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        [Fact]
        public void GetTax_MultipleChargesWithGaps_ReturnsCappedTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 14, 09, 00, 00), // 8 kr
                new DateTime(2013, 01, 14, 11, 30, 00) // 8 kr
            };
            int expectedTax = 34; // Total tax: 18 + 8 + 8 = 34

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        [Fact]
        public void GetTax_MultipleChargesWithin60Minutes_ReturnsHighestTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 14, 07, 30, 00), // 13 kr
                new DateTime(2013, 01, 14, 07, 59, 00), // 18 kr
            };
            int expectedTax = 18; // Should return the highest tax only

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        [Fact]
        public void GetTax_MultipleDaysCharges_ReturnsTotalTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 07, 00, 00), // 18 kr
                new DateTime(2013, 01, 15, 08, 00, 00)  // 13 kr
            };
            int expectedTax = 31; // Total tax: 18 + 13 = 31

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }

        [Fact]
        public void GetTax_TaxForNonExemptVehicle_ReturnsCorrectTax()
        {
            // Arrange
            DateTime[] dates = {
                new DateTime(2013, 01, 14, 08, 00, 00), // 13 kr
                new DateTime(2013, 01, 14, 08, 30, 00), // 8 kr
                new DateTime(2013, 01, 14, 09, 00, 00)  // 8 kr
            };
            int expectedTax = 13; // Should return the highest tax calculated

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result); // Verify the result matches the expected tax amount
        }
    }
}
