﻿using System;
using Xunit;
using congestion.calculator.Models;

namespace CongestionTaxCalculator.Tests.CarTests
{
    // Note for Development Team:
    // This class contains unit tests for the CongestionTaxCalculator, focusing on specific dates and 
    // their corresponding congestion tax calculations.
    //
    // Purpose:
    // Verify that the calculator correctly applies the tax rules for specific dates, ensuring that
    // the correct amounts are charged based on the given times.
    //
    // Scenarios covered:
    // 1. Various weekdays and their corresponding tax amounts.
    // 2. The tax amount is verified for edge cases, such as exact tax change times.
    // 3. Ensures that no tax is applied at specific times (e.g., late evenings).
    //
    // Importance:
    // Ensuring accurate tax calculations for specific dates is crucial for compliance
    // with local regulations and maintaining user trust in the application.

    public class SpecificDatesTaxTests
    {
        private readonly congestion.calculator.Calculators.CongestionTaxCalculator _calculator;
        private readonly Car _vehicle;

        public SpecificDatesTaxTests()
        {
            _calculator = new congestion.calculator.Calculators.CongestionTaxCalculator();
            _vehicle = new Car(); // Test with a standard car
        }

        // Additional test cases for specific dates
        [Fact]
        public void GetTax_TestDate1_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 14, 21, 00, 00) }; // Test Date 1
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate2_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 01, 15, 21, 00, 00) }; // Test Date 2
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate3_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 07, 06, 23, 27) }; // Test Date 3
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate4_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 07, 15, 27, 00) }; // Test Date 4
            int expectedTax = 13;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate5_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 06, 27, 00) }; // Test Date 5
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate6_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 06, 20, 27) }; // Test Date 6
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate7_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 14, 35, 00) }; // Test Date 7
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate8_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 15, 29, 00) }; // Test Date 8
            int expectedTax = 13;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate9_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 15, 47, 00) }; // Test Date 9
            int expectedTax = 18;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate10_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 16, 01, 00) }; // Test Date 10
            int expectedTax = 18;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate11_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 16, 48, 00) }; // Test Date 11
            int expectedTax = 18;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate12_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 17, 49, 00) }; // Test Date 12
            int expectedTax = 13;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate13_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 18, 29, 00) }; // Test Date 13
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate14_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 02, 08, 18, 35, 00) }; // Test Date 14
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate15_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 03, 26, 14, 25, 00) }; // Test Date 15
            int expectedTax = 8;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }

        [Fact]
        public void GetTax_TestDate16_ReturnsExpectedTax()
        {
            // Arrange
            DateTime[] dates = { new DateTime(2013, 03, 28, 14, 07, 27) }; // Test Date 16
            int expectedTax = 0;

            // Act
            int result = _calculator.GetTax(_vehicle, dates);

            // Assert
            Assert.Equal(expectedTax, result);
        }
    }
}
