using System;

namespace congestion.calculator.Models
{
    /// <summary>
    /// Represents a car, inheriting from the Vehicle base class.
    /// </summary>
    public class Car : IVehicle
    {
        /// <summary>
        /// Gets the type of the vehicle as a string.
        /// </summary>
        /// <returns>A string representing the vehicle type.</returns>
        public string GetVehicleType()
        {
            return "Car"; // Returns the vehicle type
        }
    }
}
