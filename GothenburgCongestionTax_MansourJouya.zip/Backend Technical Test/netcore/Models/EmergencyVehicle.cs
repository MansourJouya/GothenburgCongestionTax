﻿using System;

namespace congestion.calculator.Models
{
    /// <summary>
    /// Represents an emergency vehicle, inheriting from the Vehicle base class.
    /// </summary>
    public class EmergencyVehicle : IVehicle
    {
        /// <summary>
        /// Gets the type of the vehicle as a string.
        /// </summary>
        /// <returns>A string representing the vehicle type.</returns>
        public string GetVehicleType()
        {
            return "EmergencyVehicle"; // Returns the vehicle type
        }
    }
}
