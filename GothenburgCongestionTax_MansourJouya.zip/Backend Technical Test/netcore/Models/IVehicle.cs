using System;

namespace congestion.calculator.Models
{
    /// <summary>
    /// Represents a contract for vehicle types.
    /// </summary>
    public interface IVehicle
    {
        /// <summary>
        /// Gets the type of the vehicle as a string.
        /// </summary>
        /// <returns>A string representing the vehicle type.</returns>
        string GetVehicleType();
    }
}
