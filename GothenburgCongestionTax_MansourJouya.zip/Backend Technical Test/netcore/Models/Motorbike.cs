using System;

namespace congestion.calculator.Models
{
    /// <summary>
    /// Represents a motorbike, inheriting from the Vehicle base class.
    /// </summary>
    public class Motorbike : IVehicle
    {
        /// <summary>
        /// Gets the type of the vehicle as a string.
        /// </summary>
        /// <returns>A string representing the vehicle type.</returns>
        public string GetVehicleType()
        {
            return "Motorbike"; // Returns the vehicle type
        }
    }
}
