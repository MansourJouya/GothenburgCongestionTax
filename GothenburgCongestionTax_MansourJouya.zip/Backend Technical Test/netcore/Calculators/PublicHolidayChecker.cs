﻿using System;
using System.Collections.Generic;

namespace congestion.calculator.Calculators
{
    /// <summary>
    /// This class checks if a given date is a public holiday, the day before a holiday, or a weekend.
    /// </summary>
    public class PublicHolidayChecker
    {
        private readonly HashSet<DateTime> _publicHolidays; // Stores the public holiday dates

        /// <summary>
        /// Initializes a new instance of the PublicHolidayChecker class.
        /// Loads public holiday dates once during initialization.
        /// </summary>
        public PublicHolidayChecker()
        {
            _publicHolidays = LoadPublicHolidays();
        }

        /// <summary>
        /// Checks if the given date is a public holiday.
        /// </summary>
        /// <param name="date">The date to check.</param>
        /// <returns>True if the date is a public holiday; otherwise, false.</returns>
        public bool IsPublicHoliday(DateTime date)
        {
            return _publicHolidays.Contains(date.Date);
        }

        /// <summary>
        /// Checks if the given date is the day before a public holiday.
        /// </summary>
        /// <param name="date">The date to check.</param>
        /// <returns>True if the date is the day before a public holiday; otherwise, false.</returns>
        public bool IsDayBeforeHoliday(DateTime date)
        {
            return _publicHolidays.Contains(date.AddDays(1).Date);
        }

        /// <summary>
        /// Checks if the given date falls on a weekend (Saturday or Sunday).
        /// </summary>
        /// <param name="date">The date to check.</param>
        /// <returns>True if the date is a weekend; otherwise, false.</returns>
        public bool IsWeekend(DateTime date)
        {
            return date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday;
        }

        /// <summary>
        /// Loads the public holiday dates into a HashSet for quick lookup.
        /// </summary>
        /// <returns>A HashSet containing public holiday dates.</returns>
        private HashSet<DateTime> LoadPublicHolidays()
        {
            return new HashSet<DateTime>
            {
                new DateTime(2013, 1, 1),
                new DateTime(2013, 3, 28),
                new DateTime(2013, 3, 29),
                new DateTime(2013, 4, 1),
                new DateTime(2013, 5, 1),
                new DateTime(2013, 5, 8),
                new DateTime(2013, 5, 9),
                new DateTime(2013, 6, 5),
                new DateTime(2013, 6, 6),
                new DateTime(2013, 6, 21),
                new DateTime(2013, 7, 1),
                new DateTime(2013, 11, 1),
                new DateTime(2013, 12, 24),
                new DateTime(2013, 12, 25),
                new DateTime(2013, 12, 26),
                new DateTime(2013, 12, 31)
            };
        }
    }
}
