﻿using System;
using System.Collections.Generic;
using System.Linq;
using congestion.calculator.Enums;
using congestion.calculator.Models;
using congestion.calculator.Utilities;

namespace congestion.calculator.Calculators
{
    /// <summary>
    /// This class calculates the toll fee based on the vehicle type and the time of passage.
    /// It also checks for exempt vehicle types and toll-free dates.
    /// </summary>
    public class TollFeeCalculator
    {
        // Store exempt vehicle types in lowercase for efficient comparison
        private static readonly HashSet<string> ExemptVehicleTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            TollFreeVehicles.MotorcycleVehicle.ToString().ToLower(),
            TollFreeVehicles.TractorVehicle.ToString().ToLower(),
            TollFreeVehicles.EmergencyVehicle.ToString().ToLower(),
            TollFreeVehicles.DiplomatVehicle.ToString().ToLower(),
            TollFreeVehicles.ForeignVehicle.ToString().ToLower(),
            TollFreeVehicles.MilitaryVehicle.ToString().ToLower(),
            TollFreeVehicles.BusVehicle.ToString().ToLower()
        };

        // Define the time ranges for toll fees
        private static readonly List<TimeFeeRange> TimeFeeRanges = new List<TimeFeeRange>
        {
            new TimeFeeRange(6, 0, 6, 29, 8),  // 6:00 - 6:29 = 8 kr
            new TimeFeeRange(6, 30, 6, 59, 13), // 6:30 - 6:59 = 13 kr
            new TimeFeeRange(7, 0, 7, 59, 18),  // 7:00 - 7:59 = 18 kr
            new TimeFeeRange(8, 0, 8, 29, 13),  // 8:00 - 8:29 = 13 kr
            new TimeFeeRange(8, 30, 14, 59, 8), // 8:30 - 14:59 = 8 kr
            new TimeFeeRange(15, 0, 15, 29, 13), // 15:00 - 15:29 = 13 kr
            new TimeFeeRange(15, 30, 16, 59, 18), // 15:30 - 16:59 = 18 kr
            new TimeFeeRange(17, 0, 17, 59, 13), // 17:00 - 17:59 = 13 kr
            new TimeFeeRange(18, 0, 18, 29, 8)   // 18:00 - 18:29 = 8 kr
        };

        /// <summary>
        /// Gets the toll fee for a vehicle based on the passage date and time.
        /// </summary>
        /// <param name="date">The date and time of passage.</param>
        /// <param name="vehicle">The vehicle for which the toll fee is calculated.</param>
        /// <returns>The calculated toll fee, or 0 if the vehicle is exempt or it is a toll-free date.</returns>
        public int GetTollFee(DateTime date, IVehicle vehicle)
        {
            // Early exit for exempt vehicles or toll-free dates
            if (IsExemptVehicle(vehicle) || IsTollFreeDate(date) || IsJuly(date))
            {
                return 0; // No fee
            }

            TimeSpan currentTime = date.TimeOfDay; // Get the current time as a TimeSpan
            // Find the first applicable fee range and return the fee; if none found, return 0
            return TimeFeeRanges.FirstOrDefault(range => range.IsInRange(currentTime))?.Fee ?? 0;
        }

        /// <summary>
        /// Checks if the vehicle is exempt from toll fees.
        /// </summary>
        /// <param name="vehicle">The vehicle to check.</param>
        /// <returns>True if the vehicle is exempt; otherwise, false.</returns>
        private bool IsExemptVehicle(IVehicle vehicle)
        {
            if (vehicle == null) return false; // Null check
            string vehicleType = vehicle.GetVehicleType().ToLower(); // Get vehicle type in lowercase
            return ExemptVehicleTypes.Contains(vehicleType); // Check for exemption
        }

        /// <summary>
        /// Checks if the given date is a toll-free date (weekend, public holiday, or day before a holiday).
        /// </summary>
        /// <param name="date">The date to check.</param>
        /// <returns>True if the date is toll-free; otherwise, false.</returns>
        private bool IsTollFreeDate(DateTime date)
        {
            var publicHolidayChecker = new PublicHolidayChecker(); // Create an instance to check public holidays
            return publicHolidayChecker.IsWeekend(date) ||
                   publicHolidayChecker.IsPublicHoliday(date) ||
                   publicHolidayChecker.IsDayBeforeHoliday(date);
        }

        /// <summary>
        /// Checks if the given date is in the month of July.
        /// </summary>
        /// <param name="date">The date to check.</param>
        /// <returns>True if the month is July; otherwise, false.</returns>
        private bool IsJuly(DateTime date)
        {
            return date.Month == 7; // Checks if the month is July
        }
    }
}
