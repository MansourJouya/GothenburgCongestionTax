﻿using System;
using System.Linq;
using congestion.calculator.Models;
using congestion.calculator.Utilities;

namespace congestion.calculator.Calculators
{
    /// <summary>
    /// This class calculates congestion tax for vehicles based on their passage times.
    /// It manages the vehicle pass history and computes the total tax for a vehicle
    /// based on multiple date-time inputs.
    /// </summary>
    public class CongestionTaxCalculator
    {
        private readonly VehiclePassHistory vehiclePassHistory; // Manages historical toll data for vehicles
        private readonly TollFeeCalculator tollFeeCalculator;   // Calculates the toll fee based on time and vehicle type

        /// <summary>
        /// Initializes a new instance of the CongestionTaxCalculator class.
        /// </summary>
        public CongestionTaxCalculator()
        {
            vehiclePassHistory = new VehiclePassHistory();
            tollFeeCalculator = new TollFeeCalculator();
        }

        /// <summary>
        /// Calculates the total congestion tax for a vehicle based on the given passage dates.
        /// </summary>
        /// <param name="vehicle">The vehicle for which the tax is to be calculated.</param>
        /// <param name="dates">An array of DateTime representing the passage times of the vehicle.</param>
        /// <returns>The total congestion tax, capped at a maximum of 60.</returns>
        /// <exception cref="ArgumentNullException">Thrown when vehicle is null.</exception>
        /// <exception cref="ArgumentException">Thrown when dates array is null or empty.</exception>
        public int GetTax(IVehicle vehicle, DateTime[] dates)
        {
            // Validate input parameters
            if (vehicle == null)
            {
                throw new ArgumentNullException(nameof(vehicle), "Vehicle cannot be null.");
            }

            if (dates == null || dates.Length == 0)
            {
                throw new ArgumentException("Dates cannot be null or empty.", nameof(dates));
            }

            // Sort the passage dates in ascending order
            var sortedDates = dates.OrderBy(d => d).ToList();
            int totalToll = 0; // Total congestion tax to be calculated
            DateTime lastDate = DateTime.MinValue; // To track the last date in the loop
            int highestTollInWindow = 0; // Highest toll fee within the current 60-minute window

            // Iterate over sorted dates to calculate the total toll
            foreach (var date in sortedDates)
            {
                int tollFee = CalculateTollForDate(vehicle, date); // Calculate toll fee for the current date

                // Check if the current date is within the 60 minutes window of the last date
                if (lastDate != DateTime.MinValue && (date - lastDate).TotalMinutes < 60)
                {
                    // Update the highest toll fee in the current window
                    highestTollInWindow = Math.Max(highestTollInWindow, tollFee);
                }
                else
                {
                    // If moving to a new window, add the highest toll fee from the previous window to the total
                    totalToll += highestTollInWindow;

                    // Reset the highest toll fee for the new window
                    highestTollInWindow = tollFee;
                }

                // Update lastDate to the current date for the next iteration
                lastDate = date;
            }

            // Add the last window's maximum toll to the total
            totalToll += highestTollInWindow;

            // Cap the total toll at 60 and return
            return Math.Min(totalToll, 60);
        }

        /// <summary>
        /// Calculates the toll fee for a specific date based on vehicle type and the calculated toll fee.
        /// </summary>
        /// <param name="vehicle">The vehicle for which the toll is being calculated.</param>
        /// <param name="date">The date for which the toll is being calculated.</param>
        /// <returns>The updated toll fee based on the vehicle's pass history.</returns>
        private int CalculateTollForDate(IVehicle vehicle, DateTime date)
        {
            // Retrieve the toll fee for the specific date and vehicle type
            int tollFee = tollFeeCalculator.GetTollFee(date, vehicle);

            // Update the vehicle's pass history and return the highest toll fee
            return vehiclePassHistory.UpdateAndGetHighestFee(vehicle, date, tollFee);
        }
    }
}
