﻿using System;

namespace congestion.calculator.Utilities
{
    /// <summary>
    /// A class representing a time range with a start time, end time, and fee.
    /// </summary>
    public class TimeFeeRange
    {
        /// <summary>
        /// Gets the start time of the fee range.
        /// </summary>
        public TimeSpan Start { get; } // Start time of the fee range

        /// <summary>
        /// Gets the end time of the fee range.
        /// </summary>
        public TimeSpan End { get; }   // End time of the fee range

        /// <summary>
        /// Gets the fee applicable for this time range.
        /// </summary>
        public int Fee { get; }         // Fee applicable for this range

        /// <summary>
        /// Initializes a new instance of the TimeFeeRange class.
        /// </summary>
        /// <param name="startHour">The starting hour of the time range.</param>
        /// <param name="startMinute">The starting minute of the time range.</param>
        /// <param name="endHour">The ending hour of the time range.</param>
        /// <param name="endMinute">The ending minute of the time range.</param>
        /// <param name="fee">The fee applicable during this time range.</param>
        public TimeFeeRange(int startHour, int startMinute, int endHour, int endMinute, int fee)
        {
            Start = new TimeSpan(startHour, startMinute, 0); // Set the start time
            End = new TimeSpan(endHour, endMinute, 59); // Set the end time (inclusive)
            Fee = fee; // Set the applicable fee
        }

        /// <summary>
        /// Checks if a given time falls within this time range.
        /// </summary>
        /// <param name="time">The time to check.</param>
        /// <returns>True if the time is within the range; otherwise, false.</returns>
        public bool IsInRange(TimeSpan time)
        {
            return time >= Start && time <= End; // Check if time is within the range
        }
    }
}
