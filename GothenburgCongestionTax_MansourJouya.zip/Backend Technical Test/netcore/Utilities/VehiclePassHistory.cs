﻿using System;
using System.Collections.Generic;
using congestion.calculator.Models;

namespace congestion.calculator.Utilities
{
    /// <summary>
    /// Manages the history of vehicle passes, including the last pass time and the highest fee recorded.
    /// </summary>
    public class VehiclePassHistory
    {
        // Dictionary to store the last pass time and the highest fee for each vehicle
        private readonly Dictionary<IVehicle, (DateTime lastPass, int highestFee)> vehicleHistory = new Dictionary<IVehicle, (DateTime, int)>();

        /// <summary>
        /// Updates the pass history for a vehicle and retrieves the highest fee recorded within the last 60 minutes.
        /// </summary>
        /// <param name="vehicle">The vehicle being processed.</param>
        /// <param name="date">The date of the current pass.</param>
        /// <param name="tollFee">The calculated toll fee for the current pass.</param>
        /// <returns>The highest fee recorded during the last 60 minutes or the current toll fee.</returns>
        public int UpdateAndGetHighestFee(IVehicle vehicle, DateTime date, int tollFee)
        {
            // Check if the vehicle already has a record
            if (vehicleHistory.ContainsKey(vehicle))
            {
                var (lastPass, highestFee) = vehicleHistory[vehicle]; // Retrieve last pass and highest fee

                // If within 60 minutes
                if ((date - lastPass).TotalMinutes <= 60)
                {
                    // Update the highest fee without changing the lastPass date
                    highestFee = Math.Max(highestFee, tollFee); // Keep the highest fee
                    vehicleHistory[vehicle] = (lastPass, highestFee); // Update the record with the new highest fee
                    return highestFee; // Return the highest fee
                }
                else // If outside 60 minutes
                {
                    // Reset the history with the new toll fee and date
                    vehicleHistory[vehicle] = (date, tollFee); // Update to the new date and toll fee
                    return tollFee; // Return the current toll fee for the new window
                }
            }

            // If the vehicle does not have a record, initialize it
            vehicleHistory[vehicle] = (date, tollFee); // Update the history with current date and toll fee
            return tollFee; // Return the current toll fee
        }
    }
}
