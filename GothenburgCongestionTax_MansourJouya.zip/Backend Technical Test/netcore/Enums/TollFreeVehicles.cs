﻿namespace congestion.calculator.Enums
{
    /// <summary>
    /// Enum representing vehicle types that are exempt from the congestion tax.
    /// </summary>
    public enum TollFreeVehicles
    {
        /// <summary>
        /// Represents a motorcycle vehicle.
        /// </summary>
        MotorcycleVehicle = 0,

        /// <summary>
        /// Represents a tractor vehicle.
        /// </summary>
        TractorVehicle = 1,

        /// <summary>
        /// Represents an emergency vehicle.
        /// </summary>
        EmergencyVehicle = 2,

        /// <summary>
        /// Represents a diplomat vehicle.
        /// </summary>
        DiplomatVehicle = 3,

        /// <summary>
        /// Represents a foreign vehicle.
        /// </summary>
        ForeignVehicle = 4,

        /// <summary>
        /// Represents a military vehicle.
        /// </summary>
        MilitaryVehicle = 5,

        /// <summary>
        /// Represents a bus vehicle.
        /// </summary>
        BusVehicle = 6
    }
}
